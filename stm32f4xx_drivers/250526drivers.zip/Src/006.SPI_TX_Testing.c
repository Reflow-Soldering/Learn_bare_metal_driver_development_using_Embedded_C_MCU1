/*
 * 006.SPI_TX_Testing.c
 *
 *  Created on: May 26, 2025
 *      Author: user
 */


int main(void)
{
	return 0;
}
